/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 80012
Source Host           : localhost:3306
Source Database       : ctf

Target Server Type    : MYSQL
Target Server Version : 80012
File Encoding         : 65001

Date: 2019-04-01 22:14:37
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_admin`
-- ----------------------------
DROP TABLE IF EXISTS `tb_admin`;
CREATE TABLE `tb_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(255) NOT NULL,
  `admin_nickname` varchar(255) DEFAULT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_tel` varchar(20) NOT NULL,
  `admin_gender` varchar(3) NOT NULL,
  `admin_email` varchar(255) DEFAULT NULL,
  `admin_photo` varchar(255) DEFAULT NULL,
  `admin_state` int(3) NOT NULL,
  PRIMARY KEY (`admin_id`,`admin_tel`),
  KEY `admin_id` (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_admin
-- ----------------------------
INSERT INTO `tb_admin` VALUES ('1', '2016210401001', 'yrb', 'yfV7Mf13LpvdN0njO1FiEYoM0b4exk/3b1QcUUOxTcVqpTAbkdtOMyR/R/LUym90yTTSnc8jNQyvsRn4YyvNtLa+WC0QkZL+NL6kKua7UJh5nxlvmqBrAvKRnOEPCRd5IFWlj5kI55xNeKXrsC5grT/QZWeIChyI7Bp1q56VJNw=', '1', '男', null, null, '3');
INSERT INTO `tb_admin` VALUES ('2', 'jtc', 'aaa', 'yfV7Mf13LpvdN0njO1FiEYoM0b4exk/3b1QcUUOxTcVqpTAbkdtOMyR/R/LUym90yTTSnc8jNQyvsRn4YyvNtLa+WC0QkZL+NL6kKua7UJh5nxlvmqBrAvKRnOEPCRd5IFWlj5kI55xNeKXrsC5grT/QZWeIChyI7Bp1q56VJNw=', '2', '女', null, null, '2');
INSERT INTO `tb_admin` VALUES ('3', 'ceshi123', '666666', 'DnYMGfSHrl06Zjj9Q2a5lx3if7GQmZAHgrzxUCyVppOQqm2zAq/NKsEtjNw91t7ExbKhYy4AkGBYExxBLy8FtorD5oz9HQQe1asPSn+1r1FN5lpyyEeqmDhPNpi1bRMyRZ4RF+I1nlya9lFb+MwsLjyXttzBmBOry0RwAWeTXek=', '13396561234', '男', '', null, '2');
INSERT INTO `tb_admin` VALUES ('4', 'ceshi002', '123456', 'DnYMGfSHrl06Zjj9Q2a5lx3if7GQmZAHgrzxUCyVppOQqm2zAq/NKsEtjNw91t7ExbKhYy4AkGBYExxBLy8FtorD5oz9HQQe1asPSn+1r1FN5lpyyEeqmDhPNpi1bRMyRZ4RF+I1nlya9lFb+MwsLjyXttzBmBOry0RwAWeTXek=', '18796561234', '男', '', null, '2');
INSERT INTO `tb_admin` VALUES ('5', 'ceshi003', '张三丰', 'sc32QL5ObE63QT8qyILz5PjDDCoroq/KBQm955U0JT/1yn5voBU8zN1xOg7RzxXF7oiN/PsnlvOW91ITOODom2H3fLdiGKZ1Z1kkwvK/MDcKiBZPiFn8q4G+RXR+upCTDn/FXZ4ky3cuth2nTjywWk61JKpIkRWlKTe019+xdiY=', '18737562200', '女', '', null, '2');
INSERT INTO `tb_admin` VALUES ('6', '123444', '111', 'ifJcAopMVp9JdpYWPfHT9+skOgJVkX9QL9x8C1J8T2esx/KUt96GUuRPhOwpuQGJuZScijVlXCwoVcEuc/Kp4FzZcY//mHoBhN9EJLIq+joLsysoG47Ag1SqTh96HxDVKpQVGzVK2HnlLRUG0nT5IVBJbCdztSLkbuCj3v32Dv4=', '13396561234', '男', '', null, '2');

-- ----------------------------
-- Table structure for `tb_area`
-- ----------------------------
DROP TABLE IF EXISTS `tb_area`;
CREATE TABLE `tb_area` (
  `area_id` int(2) NOT NULL AUTO_INCREMENT,
  `area_name` varchar(200) NOT NULL,
  `priority` int(2) NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  `last_edit_time` datetime DEFAULT NULL,
  PRIMARY KEY (`area_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_area
-- ----------------------------
INSERT INTO `tb_area` VALUES ('1', '东苑', '2', null, null);
INSERT INTO `tb_area` VALUES ('2', '北苑', '1', null, null);

-- ----------------------------
-- Table structure for `tb_competition`
-- ----------------------------
DROP TABLE IF EXISTS `tb_competition`;
CREATE TABLE `tb_competition` (
  `competition_id` int(11) NOT NULL AUTO_INCREMENT,
  `competition_title` varchar(255) NOT NULL,
  `competition_start` datetime NOT NULL,
  `competition_end` datetime NOT NULL,
  `competition_createtime` datetime NOT NULL,
  `competition_canregister` int(11) NOT NULL,
  `competition_isteam` int(11) NOT NULL,
  `competition_number` varchar(255) NOT NULL,
  `competition_holder` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`competition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_competition
-- ----------------------------
INSERT INTO `tb_competition` VALUES ('1', '杭师大第一届丰子涵杯ctf比赛', '2019-01-10 20:13:53', '2019-01-27 20:13:59', '2019-01-08 20:14:06', '1', '1', 'HZNUCTF001', null);
INSERT INTO `tb_competition` VALUES ('2', '杭师大丰子涵纪念ctf赛', '2019-01-23 20:17:00', '2019-01-24 20:17:03', '2019-01-08 20:17:10', '0', '0', 'HZNUCTF002', null);
INSERT INTO `tb_competition` VALUES ('3', '111', '2019-01-24 19:14:51', '2019-01-08 19:14:54', '2019-01-24 19:15:01', '0', '0', 'HZNUCTF003', null);
INSERT INTO `tb_competition` VALUES ('4', '比赛测试001', '2019-04-01 20:00:00', '2019-04-01 23:00:00', '2019-04-01 19:01:38', '0', '1', '123456', 'islab');
INSERT INTO `tb_competition` VALUES ('5', 'ceshi002', '2019-04-01 20:00:00', '2019-04-01 23:00:00', '2019-04-01 19:31:29', '0', '1', '666', '666');
INSERT INTO `tb_competition` VALUES ('6', 'ceshiceshi', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 19:32:34', '0', '1', '123', '123');
INSERT INTO `tb_competition` VALUES ('7', 'ceshiceshi', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 19:34:51', '0', '1', '123', '123');
INSERT INTO `tb_competition` VALUES ('8', 'ceshiceshi', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 19:34:56', '0', '1', '123', '123');
INSERT INTO `tb_competition` VALUES ('9', '12345', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 19:35:30', '0', '1', '12345', '12345');
INSERT INTO `tb_competition` VALUES ('10', 'aa', '2019-04-01 00:00:00', '2019-04-01 20:00:00', '2019-04-01 19:37:34', '0', '1', 'aa', 'aa');
INSERT INTO `tb_competition` VALUES ('11', 'aaaaa', '2019-04-01 00:00:00', '2019-04-01 04:00:00', '2019-04-01 19:39:39', '0', '1', 'aaaaa', 'aaa');
INSERT INTO `tb_competition` VALUES ('12', 'qqq', '2019-04-01 00:00:00', '2019-04-01 05:00:00', '2019-04-01 19:42:59', '0', '1', 'qq', 'qq');
INSERT INTO `tb_competition` VALUES ('13', 'zzz', '2019-04-01 00:00:00', '2019-04-01 04:00:00', '2019-04-01 19:45:29', '0', '1', 'zz', 'zzz');
INSERT INTO `tb_competition` VALUES ('14', 'aaa', '2019-04-01 00:00:00', '2019-04-01 04:00:00', '2019-04-01 19:47:05', '0', '1', 'aa', 'aa');
INSERT INTO `tb_competition` VALUES ('15', 'zzz', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 19:48:43', '0', '1', 'zz', 'zz');
INSERT INTO `tb_competition` VALUES ('16', 'zzz', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 19:49:07', '0', '1', 'zz', 'zz');
INSERT INTO `tb_competition` VALUES ('17', 'zzz11', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 19:50:27', '0', '1', 'zz11', 'zz11');
INSERT INTO `tb_competition` VALUES ('18', 'zzz11', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 19:54:41', '0', '1', 'zz11', 'zz11');
INSERT INTO `tb_competition` VALUES ('19', 'qwe', '2019-04-01 04:00:00', '2019-04-01 18:00:00', '2019-04-01 19:55:18', '0', '1', 'qq', 'qq');
INSERT INTO `tb_competition` VALUES ('20', '121212', '2019-04-01 00:00:00', '2019-04-01 10:00:00', '2019-04-01 19:59:40', '0', '1', '1212', '1212');
INSERT INTO `tb_competition` VALUES ('21', 'qqq', '2019-04-01 01:00:00', '2019-04-01 13:00:00', '2019-04-01 20:01:41', '0', '1', 'qq', 'qq');
INSERT INTO `tb_competition` VALUES ('22', 'qqqq', '2019-04-01 01:00:00', '2019-04-01 13:00:00', '2019-04-01 20:01:50', '0', '1', 'qq', 'qq');
INSERT INTO `tb_competition` VALUES ('23', 'qweqweqwe', '2019-04-01 00:00:00', '2019-04-01 09:00:00', '2019-04-01 20:04:00', '0', '1', 'qq', 'qq');
INSERT INTO `tb_competition` VALUES ('24', 'qqqwww', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 20:06:18', '0', '1', 'qqq', 'qq');
INSERT INTO `tb_competition` VALUES ('25', 'qqqwww', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 20:06:49', '0', '1', 'qqq', 'qq');
INSERT INTO `tb_competition` VALUES ('26', 'qqqwwwqq', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 20:06:56', '0', '1', 'qqq', 'qq');
INSERT INTO `tb_competition` VALUES ('27', 'qqqwwwqqqq', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 20:07:26', '0', '1', 'qqq', 'qq');
INSERT INTO `tb_competition` VALUES ('28', '00000', '2019-04-01 00:00:00', '2019-04-01 03:00:00', '2019-04-01 20:09:01', '0', '1', 'qqq', 'qq');
INSERT INTO `tb_competition` VALUES ('29', 'zxc', '2019-04-01 00:00:00', '2019-04-01 08:00:00', '2019-04-01 20:10:58', '0', '1', 'zz', 'zz');
INSERT INTO `tb_competition` VALUES ('30', 'sadfdgdadfg', '2019-04-01 00:00:00', '2019-04-01 23:59:59', '2019-04-01 20:13:01', '0', '1', 'sd', 'dsd');

-- ----------------------------
-- Table structure for `tb_competitionadmin`
-- ----------------------------
DROP TABLE IF EXISTS `tb_competitionadmin`;
CREATE TABLE `tb_competitionadmin` (
  `competitionadmin_id` int(11) NOT NULL AUTO_INCREMENT,
  `competition_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  PRIMARY KEY (`competitionadmin_id`),
  KEY `competitionadmin_ibfk_1` (`competition_id`),
  KEY `competitionadmin_ibfk_2` (`admin_id`),
  CONSTRAINT `competitionadmin_ibfk_1` FOREIGN KEY (`competition_id`) REFERENCES `tb_competition` (`competition_id`) ON DELETE CASCADE,
  CONSTRAINT `competitionadmin_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `tb_admin` (`admin_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_competitionadmin
-- ----------------------------
INSERT INTO `tb_competitionadmin` VALUES ('6', '20', '1');
INSERT INTO `tb_competitionadmin` VALUES ('7', '20', '2');
INSERT INTO `tb_competitionadmin` VALUES ('8', '20', '3');
INSERT INTO `tb_competitionadmin` VALUES ('9', '22', '1');
INSERT INTO `tb_competitionadmin` VALUES ('10', '22', '2');
INSERT INTO `tb_competitionadmin` VALUES ('11', '22', '3');
INSERT INTO `tb_competitionadmin` VALUES ('12', '23', '1');
INSERT INTO `tb_competitionadmin` VALUES ('13', '23', '2');
INSERT INTO `tb_competitionadmin` VALUES ('14', '23', '3');
INSERT INTO `tb_competitionadmin` VALUES ('15', '24', '2');
INSERT INTO `tb_competitionadmin` VALUES ('16', '24', '1');
INSERT INTO `tb_competitionadmin` VALUES ('17', '24', '3');
INSERT INTO `tb_competitionadmin` VALUES ('18', '26', '2');
INSERT INTO `tb_competitionadmin` VALUES ('19', '26', '1');
INSERT INTO `tb_competitionadmin` VALUES ('20', '26', '3');
INSERT INTO `tb_competitionadmin` VALUES ('21', '27', '2');
INSERT INTO `tb_competitionadmin` VALUES ('22', '27', '1');
INSERT INTO `tb_competitionadmin` VALUES ('23', '27', '3');
INSERT INTO `tb_competitionadmin` VALUES ('24', '28', '2');
INSERT INTO `tb_competitionadmin` VALUES ('25', '28', '1');
INSERT INTO `tb_competitionadmin` VALUES ('26', '28', '3');
INSERT INTO `tb_competitionadmin` VALUES ('27', '29', '1');
INSERT INTO `tb_competitionadmin` VALUES ('28', '29', '2');
INSERT INTO `tb_competitionadmin` VALUES ('29', '29', '3');
INSERT INTO `tb_competitionadmin` VALUES ('30', '30', '1');
INSERT INTO `tb_competitionadmin` VALUES ('31', '30', '2');
INSERT INTO `tb_competitionadmin` VALUES ('32', '30', '3');

-- ----------------------------
-- Table structure for `tb_competitionquestion`
-- ----------------------------
DROP TABLE IF EXISTS `tb_competitionquestion`;
CREATE TABLE `tb_competitionquestion` (
  `competition_question_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `competition_id` int(11) NOT NULL,
  `question_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`competition_question_id`),
  KEY `tb_competitionquestion_ibfk_1` (`question_id`),
  KEY `tb_competitionquestion_ibfk_2` (`competition_id`),
  CONSTRAINT `tb_competitionquestion_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `tb_question` (`question_id`) ON DELETE CASCADE,
  CONSTRAINT `tb_competitionquestion_ibfk_2` FOREIGN KEY (`competition_id`) REFERENCES `tb_competition` (`competition_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_competitionquestion
-- ----------------------------
INSERT INTO `tb_competitionquestion` VALUES ('11', '1008', '24', '1');
INSERT INTO `tb_competitionquestion` VALUES ('12', '1011', '24', '2');
INSERT INTO `tb_competitionquestion` VALUES ('13', '1009', '24', '3');
INSERT INTO `tb_competitionquestion` VALUES ('14', '1008', '26', '1');
INSERT INTO `tb_competitionquestion` VALUES ('15', '1011', '26', '2');
INSERT INTO `tb_competitionquestion` VALUES ('16', '1009', '26', '3');
INSERT INTO `tb_competitionquestion` VALUES ('17', '1008', '27', '1');
INSERT INTO `tb_competitionquestion` VALUES ('18', '1011', '27', '2');
INSERT INTO `tb_competitionquestion` VALUES ('19', '1009', '27', '3');
INSERT INTO `tb_competitionquestion` VALUES ('20', '1008', '28', '1');
INSERT INTO `tb_competitionquestion` VALUES ('21', '1011', '28', '2');
INSERT INTO `tb_competitionquestion` VALUES ('22', '1009', '28', '3');
INSERT INTO `tb_competitionquestion` VALUES ('23', '1008', '29', '1');
INSERT INTO `tb_competitionquestion` VALUES ('24', '1011', '29', '2');
INSERT INTO `tb_competitionquestion` VALUES ('25', '1009', '29', '3');
INSERT INTO `tb_competitionquestion` VALUES ('26', '1008', '30', '1');
INSERT INTO `tb_competitionquestion` VALUES ('27', '1011', '30', '2');
INSERT INTO `tb_competitionquestion` VALUES ('28', '1009', '30', '3');

-- ----------------------------
-- Table structure for `tb_competitionuser`
-- ----------------------------
DROP TABLE IF EXISTS `tb_competitionuser`;
CREATE TABLE `tb_competitionuser` (
  `competitionuser_id` int(11) NOT NULL AUTO_INCREMENT,
  `competition_id` int(11) NOT NULL,
  `competitor_id` int(11) NOT NULL,
  PRIMARY KEY (`competitionuser_id`),
  KEY `competitionuser_ibfk_1` (`competition_id`),
  KEY `competitionuser_ibfk_2` (`competitor_id`),
  CONSTRAINT `competitionuser_ibfk_1` FOREIGN KEY (`competition_id`) REFERENCES `tb_competition` (`competition_id`) ON DELETE CASCADE,
  CONSTRAINT `competitionuser_ibfk_2` FOREIGN KEY (`competitor_id`) REFERENCES `tb_user` (`competitor_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_competitionuser
-- ----------------------------
INSERT INTO `tb_competitionuser` VALUES ('23', '30', '1');
INSERT INTO `tb_competitionuser` VALUES ('24', '30', '2');

-- ----------------------------
-- Table structure for `tb_information`
-- ----------------------------
DROP TABLE IF EXISTS `tb_information`;
CREATE TABLE `tb_information` (
  `information_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `information_detail` varchar(255) NOT NULL,
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`information_id`),
  KEY `tb_information_ibfk_1` (`admin_id`),
  CONSTRAINT `tb_information_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `tb_admin` (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_information
-- ----------------------------
INSERT INTO `tb_information` VALUES ('1', '1', '阿萨德群翁', '2019-03-28 23:11:24');

-- ----------------------------
-- Table structure for `tb_question`
-- ----------------------------
DROP TABLE IF EXISTS `tb_question`;
CREATE TABLE `tb_question` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_title` varchar(255) NOT NULL,
  `question_type_id` int(11) NOT NULL,
  `question_body` text NOT NULL,
  `question_resource` text NOT NULL,
  `question_answer` varchar(255) NOT NULL,
  `question_create_time` datetime NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `question_author` varchar(255) NOT NULL,
  `question_point` int(11) NOT NULL,
  `question_decrease` int(11) DEFAULT NULL,
  `question_additional` int(11) DEFAULT NULL,
  `question_level` int(11) DEFAULT NULL,
  PRIMARY KEY (`question_id`),
  KEY `tb_question_ibfk1` (`question_type_id`),
  CONSTRAINT `tb_question_ibfk1` FOREIGN KEY (`question_type_id`) REFERENCES `tb_questiontype` (`question_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1012 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_question
-- ----------------------------
INSERT INTO `tb_question` VALUES ('1008', 'question001', '1', '123456', '/upload/problemResource/201903311755415910671.txt', '12456', '2019-03-31 17:55:41', null, '12345', '10', '1', '5', '10');
INSERT INTO `tb_question` VALUES ('1009', 'question002', '2', '123456', '/upload/problemResource/20190331175712894346zh 51  新.txt', '123456', '2019-03-31 17:57:12', null, '123123', '120', '1', '5', '10');
INSERT INTO `tb_question` VALUES ('1010', '题目123', '4', '123456', '/upload/problemResource/201903311952366520091.txt', '000000', '2019-03-31 19:52:36', null, '00', '22', '1', '2', '10');
INSERT INTO `tb_question` VALUES ('1011', '1111111111', '1', '11', '/upload/problemResource/20190401160310698792新建文本文档.txt', '11', '2019-04-01 16:03:10', null, '11', '111', '1', '11', '11');

-- ----------------------------
-- Table structure for `tb_questiontype`
-- ----------------------------
DROP TABLE IF EXISTS `tb_questiontype`;
CREATE TABLE `tb_questiontype` (
  `question_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_type` varchar(255) NOT NULL,
  `question_type_introduction` varchar(255) NOT NULL,
  PRIMARY KEY (`question_type_id`),
  KEY `question_type` (`question_type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_questiontype
-- ----------------------------
INSERT INTO `tb_questiontype` VALUES ('1', 'PWN', 'aaaaaaaaaaaaaaaa');
INSERT INTO `tb_questiontype` VALUES ('2', 'Web', 'bb');
INSERT INTO `tb_questiontype` VALUES ('3', '渗透', 'cc');
INSERT INTO `tb_questiontype` VALUES ('4', '逆向', 'dd');
INSERT INTO `tb_questiontype` VALUES ('6', 'ceshi1', 'ff');
INSERT INTO `tb_questiontype` VALUES ('7', 'ceshi2', 'gg');
INSERT INTO `tb_questiontype` VALUES ('8', 'ceshi003', '123456');

-- ----------------------------
-- Table structure for `tb_record`
-- ----------------------------
DROP TABLE IF EXISTS `tb_record`;
CREATE TABLE `tb_record` (
  `answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `competition_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `competitor_id` int(11) NOT NULL,
  `answer_time` datetime NOT NULL,
  `answer_body` varchar(255) NOT NULL,
  `answer_result` int(11) NOT NULL,
  `answer_get_point` float NOT NULL,
  PRIMARY KEY (`answer_id`),
  KEY `tb_record_ibfk_1` (`competitor_id`),
  KEY `tb_record_ibfk_3` (`team_id`),
  KEY `tb_record_ibfk_4` (`question_id`),
  KEY `tb_record_ibfk_5` (`competition_id`),
  CONSTRAINT `tb_record_ibfk_1` FOREIGN KEY (`competitor_id`) REFERENCES `tb_user` (`competitor_id`) ON DELETE CASCADE,
  CONSTRAINT `tb_record_ibfk_3` FOREIGN KEY (`team_id`) REFERENCES `tb_team` (`team_id`) ON DELETE CASCADE,
  CONSTRAINT `tb_record_ibfk_4` FOREIGN KEY (`question_id`) REFERENCES `tb_question` (`question_id`) ON DELETE CASCADE,
  CONSTRAINT `tb_record_ibfk_5` FOREIGN KEY (`competition_id`) REFERENCES `tb_competition` (`competition_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_record
-- ----------------------------

-- ----------------------------
-- Table structure for `tb_team`
-- ----------------------------
DROP TABLE IF EXISTS `tb_team`;
CREATE TABLE `tb_team` (
  `team_id` int(11) NOT NULL AUTO_INCREMENT,
  `team_name` varchar(255) NOT NULL,
  `team_competition_id` int(11) NOT NULL,
  `team_point` float(32,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`team_id`,`team_competition_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_team
-- ----------------------------
INSERT INTO `tb_team` VALUES ('1', 'fzhnb', '30', '0.00');
INSERT INTO `tb_team` VALUES ('2', 'yepang weiwu', '30', '0.00');

-- ----------------------------
-- Table structure for `tb_teamcompetitor`
-- ----------------------------
DROP TABLE IF EXISTS `tb_teamcompetitor`;
CREATE TABLE `tb_teamcompetitor` (
  `teamcompetitor_id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `competitor_id` int(11) NOT NULL,
  `competitor_level` int(5) NOT NULL,
  PRIMARY KEY (`teamcompetitor_id`),
  KEY `tb_teamcompetitor_ibfk_1` (`team_id`),
  KEY `tb_teamcompetitor_ibfk_2` (`competitor_id`),
  CONSTRAINT `tb_teamcompetitor_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `tb_team` (`team_id`) ON DELETE CASCADE,
  CONSTRAINT `tb_teamcompetitor_ibfk_2` FOREIGN KEY (`competitor_id`) REFERENCES `tb_user` (`competitor_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_teamcompetitor
-- ----------------------------
INSERT INTO `tb_teamcompetitor` VALUES ('35', '1', '1', '1');
INSERT INTO `tb_teamcompetitor` VALUES ('43', '2', '2', '1');

-- ----------------------------
-- Table structure for `tb_user`
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `competitor_id` int(11) NOT NULL AUTO_INCREMENT,
  `competitor_username` varchar(255) NOT NULL,
  `competitor_password` varchar(255) NOT NULL,
  `competitor_nickname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `competitor_tel` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `competitor_academy` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `competitor_class` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `competitor_studentnumber` varchar(255) NOT NULL,
  `competitor_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`competitor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES ('1', 'yepang', 'yfV7Mf13LpvdN0njO1FiEYoM0b4exk/3b1QcUUOxTcVqpTAbkdtOMyR/R/LUym90yTTSnc8jNQyvsRn4YyvNtLa+WC0QkZL+NL6kKua7UJh5nxlvmqBrAvKRnOEPCRd5IFWlj5kI55xNeKXrsC5grT/QZWeIChyI7Bp1q56VJNw=', 'yeruibin', '111', '1', '1', '1', null);
INSERT INTO `tb_user` VALUES ('2', 'fzh', 'yfV7Mf13LpvdN0njO1FiEYoM0b4exk/3b1QcUUOxTcVqpTAbkdtOMyR/R/LUym90yTTSnc8jNQyvsRn4YyvNtLa+WC0QkZL+NL6kKua7UJh5nxlvmqBrAvKRnOEPCRd5IFWlj5kI55xNeKXrsC5grT/QZWeIChyI7Bp1q56VJNw=', 'fzhtql', '222', '1', '1', '2', null);
INSERT INTO `tb_user` VALUES ('3', 'zyx', 'yfV7Mf13LpvdN0njO1FiEYoM0b4exk/3b1QcUUOxTcVqpTAbkdtOMyR/R/LUym90yTTSnc8jNQyvsRn4YyvNtLa+WC0QkZL+NL6kKua7UJh5nxlvmqBrAvKRnOEPCRd5IFWlj5kI55xNeKXrsC5grT/QZWeIChyI7Bp1q56VJNw=', 'zyxsp', '333', '1', '1', '3', null);
INSERT INTO `tb_user` VALUES ('9', 'haha', 'yfV7Mf13LpvdN0njO1FiEYoM0b4exk/3b1QcUUOxTcVqpTAbkdtOMyR/R/LUym90yTTSnc8jNQyvsRn4YyvNtLa+WC0QkZL+NL6kKua7UJh5nxlvmqBrAvKRnOEPCRd5IFWlj5kI55xNeKXrsC5grT/QZWeIChyI7Bp1q56VJNw=', 'jiatiechengoo', '17376592886', '1', '2', '4', null);
INSERT INTO `tb_user` VALUES ('10', 'haha1', 'yfV7Mf13LpvdN0njO1FiEYoM0b4exk/3b1QcUUOxTcVqpTAbkdtOMyR/R/LUym90yTTSnc8jNQyvsRn4YyvNtLa+WC0QkZL+NL6kKua7UJh5nxlvmqBrAvKRnOEPCRd5IFWlj5kI55xNeKXrsC5grT/QZWeIChyI7Bp1q56VJNw=', 'jiatiechengoo', '17376592886', '2', '2', '5', null);
INSERT INTO `tb_user` VALUES ('12', '1asdasd6', 'yfV7Mf13LpvdN0njO1FiEYoM0b4exk/3b1QcUUOxTcVqpTAbkdtOMyR/R/LUym90yTTSnc8jNQyvsRn4YyvNtLa+WC0QkZL+NL6kKua7UJh5nxlvmqBrAvKRnOEPCRd5IFWlj5kI55xNeKXrsC5grT/QZWeIChyI7Bp1q56VJNw=', 'haha', '1', '1', '2', '321', null);
INSERT INTO `tb_user` VALUES ('13', '123456789', 'yfV7Mf13LpvdN0njO1FiEYoM0b4exk/3b1QcUUOxTcVqpTAbkdtOMyR/R/LUym90yTTSnc8jNQyvsRn4YyvNtLa+WC0QkZL+NL6kKua7UJh5nxlvmqBrAvKRnOEPCRd5IFWlj5kI55xNeKXrsC5grT/QZWeIChyI7Bp1q56VJNw=', 'haha', '2', '2', '2', '321', null);
INSERT INTO `tb_user` VALUES ('14', '123456712389', 'yfV7Mf13LpvdN0njO1FiEYoM0b4exk/3b1QcUUOxTcVqpTAbkdtOMyR/R/LUym90yTTSnc8jNQyvsRn4YyvNtLa+WC0QkZL+NL6kKua7UJh5nxlvmqBrAvKRnOEPCRd5IFWlj5kI55xNeKXrsC5grT/QZWeIChyI7Bp1q56VJNw=', 'haha', '3', '2', '2', '321', null);
INSERT INTO `tb_user` VALUES ('15', '321jj', 'xzqM6xFI8ct4MmdBO0J6Gx8ZYtt1bGCY5mdt02kLAzzIQXfgbYqIK80fBSNkl6XWdBBoFoBIMNpLq8eNx5Ux+SD58sXGu6CMbSAPBGFlelAXMZZYb7aZnnQDuaefihw1am+maEjPkDAipdRFU9zW+HQLKrvJvJdU8sjVlXyA3I4=', '137', '4', '1', '2', '654123', null);
INSERT INTO `tb_user` VALUES ('16', 'yucheng', 'xzqM6xFI8ct4MmdBO0J6Gx8ZYtt1bGCY5mdt02kLAzzIQXfgbYqIK80fBSNkl6XWdBBoFoBIMNpLq8eNx5Ux+SD58sXGu6CMbSAPBGFlelAXMZZYb7aZnnQDuaefihw1am+maEjPkDAipdRFU9zW+HQLKrvJvJdU8sjVlXyA3I4=', 'asdas', '17376292886', '国服', '1234', '2017212212222', '44');
