#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include<windows.h>

char input[50];
BYTE enc_flag[49] = { 0x46,0x4c,0x41,0x47,0x7b,0x77,0x30,0x77,0x5f,0x21,0x21,0x21,0x47,0x30,0x30,0x64,0x19,0x6,0x71,0x25,0x24,0x56,0x11,0x56,0x6,0x4e,0x54,0x7e,0x26,0x62,0x3,0x3b,0x2c,0x36,0x2e,0x60,0x5c,0x15,0x74,0x67,0x37,0x2b,0x3a,0xa,0x79,0x43,0x22,0x1a,0x51 };
BYTE encrypt1(BYTE a, BYTE b) {
     BYTE temp1 = (a&(~b));
     BYTE temp2 = ((~a)&b);
     a = (temp1 | temp2);
     return a;
}

BYTE encrypt2(BYTE a, BYTE b) {
     BYTE temp1 = (a&b);
     BYTE temp2 = ((~a)&(~b));
     a = (~(temp1 | temp2));
     return a;
}

BYTE encrypt3(BYTE a, BYTE b) {
     BYTE temp1 = (a | b);
     BYTE temp2 = ((~a) | (~b));
     a = (temp1 & temp2);
     return a;
}

void strict_check() {
     srand(time(NULL));
     int magic1 = rand() % 0x1234;
     int magic2 = rand() % 0x5678;
     int x = input[11], y = input[17];
     int result1 = magic1 * magic1 + magic2 * magic2;
     int result2 = x * x + y * y;
     int result3 = (magic1*x + magic2 * y);
     if (result1*result2 < result3*result3) {
          puts("Goodbye...");
          exit(0);
     }
     puts("Lucky enough!");
}

int main(int argc, char**argv) {
     fgets(input, 50, stdin);
     strict_check();
     BYTE i;
     for (i = 0; i <= 2; i++) {
          for (BYTE j = 2; j < 49; j++) {
               input[j] = encrypt1(input[j], input[j - 2]);
          }
     }
     for (i = 3; i <= 5; i++) {
          for (BYTE j = 2; j < 49; j++) {
               input[j] = encrypt2(input[j], input[j - 2]);
          }
     }
     for (i = 6; i <= 7; i++) {
          for (BYTE j = 2; j < 49; j++) {
               input[j] = encrypt3(input[j], input[j - 2]);
          }
     }
     int count;
     for (count = 0; count < 49; count++) {
          if (input[count] != enc_flag[count])
               break;
     }
     if (count == 49) { puts("nice!you made it!"); }
     else { puts("You failed!"); }
     system("pause");
}