#include<iostream>
#include<Windows.h>
#include<string>
extern   "C"{
     #include "miracl.h"
     #include "mirdef.h"
}
using namespace std;

void en(big a, big *b, big e, big n) {
     powmod(a, e, n, *b);//dy=z^x%n
}
void flag(big z, char a[]) {
     big b;
     b = mirvar(0);
     cinstr(b, a);
     if (!compare(z,b)){
          cout << "Congratulation!" << endl;
     } else {
          cout << "Wrong!" << endl;
          cout << "Bye_Bye!" << endl;
     }
}

int main() {
     int i = 2,f=0;
     char a[] = "78679c0e24306c6da89a4ed65425bee0d5e7a2b00f2d4ef51c";
     char bb[100];
     char b[100],*pb;
     big q,p,n,pn,m;
     big e, ed, y, dy, z;
     miracl *mip = mirsys(200, 16);
     e = mirvar(0); y = mirvar(0); z = mirvar(0); ed = mirvar(0); dy = mirvar(0);
     n = mirvar(0); pn = mirvar(0); q = mirvar(5); p = mirvar(0); m = mirvar(0);
     bigbits(100, q);
     while (!isprime(q)) {
          bigbits(100, q);
     }
     bigbits(100, p);
     while (!isprime(p)) {
          bigbits(100, p);
     }
     incr(p, -380, e);//...ȡe
     multiply(q, p, n);//�� n
     incr(q, -1, q);
     incr(p, -1, p);
     multiply(q, p, pn);//��pn
     cout << "������flag:" << endl;

     cin.getline(bb, 100);
     if (strlen(bb) >= 50) {
          cout << "TOO_Loog!!"<<endl;
          system("pause");
          exit(0);
     }
     else {
          int n;
          pb = b;
          for (int i = 0; i < strlen(bb); i++) {
               n=sprintf(pb, "%x", bb[i]);
               pb+=n;
          }
          *pb = '\0';
     }
     //cout << b << endl;
     mip->IOBASE = 16;
     cinstr(m, b);

     en(m, &z, e, n);    //����

     flag(z, a);

     system("pause");
     return 0;
}