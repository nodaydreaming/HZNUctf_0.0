document.getElementsByClassName('nav-li-2')[0].onclick = function () {
    alert('Development......');
}

document.getElementsByClassName('nav-li-4')[0].onclick = function () {
    alert('Development......');
}

